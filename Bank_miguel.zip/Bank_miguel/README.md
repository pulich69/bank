Generar el redme con la descripción del proyecto
