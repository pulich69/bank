package com.appbank.bank.model;

public class LocalDeteTime {

}
