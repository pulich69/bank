create database PORTERIA_DE_LA_U;

USE PORTERIA_DE_LA_U;

create table Estudiante (
    id_estudiante INT AUTO_INCREMENT PRIMARY KEY,
    tipo_documento VARCHAR(10),
    documento VARCHAR(20) UNIQUE,
    nombres VARCHAR(100),
    apellidos VARCHAR(100),
    correo VARCHAR(100),
    telefono VARCHAR(20)
);
create table Profesor (
    id_profesor INT AUTO_INCREMENT PRIMARY KEY,
    tipo_documento VARCHAR(10),
    documento VARCHAR(20) UNIQUE,
    nombres VARCHAR(100),
    apellidos VARCHAR(100),
    correo VARCHAR(100),
    telefono VARCHAR(20)
);
create table Administrativo (
    id_administrativo INT AUTO_INCREMENT PRIMARY KEY,
    tipo_documento VARCHAR(10),
    documento VARCHAR(20) UNIQUE,
    nombres VARCHAR(100),
    apellidos VARCHAR(100),
    correo VARCHAR(100),
    telefono VARCHAR(20)
);


create table accesos (
    id_acceso INT AUTO_INCREMENT PRIMARY KEY,
    id_persona INT,
    fecha_hora DATETIME ,
    tipo_acceso VARCHAR(50),
    observaciones VARCHAR(255)
);
	
create table usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre_usuario VARCHAR(50) UNIQUE,
    contraseña VARCHAR(255),
    rol VARCHAR(50)
);

