USE PORTERIA_DE_LA_U;

-- Insertar estudiantes
INSERT INTO Estudiante ( id_estudiante ,tipo_documento, documento, nombres, apellidos, correo, telefono)
VALUES
(1,'CC', '1001', 'Juan', 'Pérez', 'juan.perez@uni.edu', '3001112222'),
(2,'CC', '1002', 'Laura', 'Gómez', 'laura.gomez@uni.edu', '3003334444');

-- Insertar profesores
INSERT INTO Profesor (id_profesor ,tipo_documento, documento, nombres, apellidos, correo, telefono)
VALUES
('CC', '2001', 'Carlos', 'Ramírez', 'carlos.ramirez@uni.edu', '3015556666'),
('CC', '2002', 'Ana', 'Torres', 'ana.torres@uni.edu', '3027778888');

-- Insertar administrativos
INSERT INTO Administrativo (id_administrativo ,tipo_documento, documento, nombres, apellidos, correo, telefono)
VALUES
('CC', '3001', 'María', 'Rojas', 'maria.rojas@uni.edu', '3039990000');

-- Insertar accesos simulados (6 eventos)
INSERT INTO accesos (id_persona, rol, fecha_hora, tipo_acceso, observaciones)
VALUES
(1, 'Estudiante', '2025-10-17 07:50:00', 'Entrada', 'Ingreso puntual'),
(2, 'Estudiante', '2025-10-17 12:00:00', 'Salida', 'Salida al almuerzo'),
(1, 'Estudiante', '2025-10-17 13:00:00', 'Entrada', 'Regreso a clase'),
(3, 'Profesor', '2025-10-17 08:05:00', 'Entrada', 'Ingreso temprano'),
(4, 'Profesor', '2025-10-17 16:00:00', 'Salida', 'Salida después de clase'),
(5, 'Administrativo', '2025-10-17 09:00:00', 'Entrada', 'Ingreso administrativo');

-- Insertar usuarios del sistema
INSERT INTO usuarios (id_usuario ,nombre_usuario, contraseña, rol)
VALUES
('admin', 'admin123', 'Administrador'),
('juanp', '12345', 'Estudiante'),
('laurag', '12345', 'Estudiante'),
('carlosr', '12345', 'Profesor'),
('anat', '12345', 'Profesor'),
('mariar', '12345', 'Administrativo');
