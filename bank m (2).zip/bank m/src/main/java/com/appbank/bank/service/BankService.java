package com.appbank.bank.service;

import java.util.List;
import com.appbank.bank.model.Account;
import com.appbank.bank.model.Customer;
import com.appbank.bank.model.Transaction;

public interface BankService {

    Customer creaCustomer(String id, String name, String email);
    Customer findCustomerById(String customerId);
    List<Customer> getAllCustomers();

 //gestion de cuentas
    Account createSavingsAccount(String accountId, Customer customer, double interestRate);
    Account createCheckAccount(String accountId, Customer customer, double overdraftLimit);
    Account findAccountById(String accountId);
    List<Account> getAllAccounts();



 //operaciones bancarias
    boolean deposit(String accountId, double amount);
    boolean withdraw(String accountId, double amount);
    boolean transfer(String fromAccountId, String toAccountId, double amount);
//intereses 
    void applyInterest(String accountId);

//consultas
    List<Transaction> getAccountTransactions(String accountId);
}