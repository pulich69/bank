package com.appbank.bank.service;

public class Account {

}
