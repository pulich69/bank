package com.appbank.bank.Repositorio;

import java.util.List;
import java.util.Optional;



public interface JsonRepositorio<T> {
    List<T> findAll(); //read
    Optional<T> findById (String id); //read 
    void save (T entity); //create
    void update (T entity); //update
    void delete (String id); //delete
}
