package com.appbank.bank.Repositorio;

import java.io.File;
import java.io.IOException;
import java.util.List;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class FileManager <T>{
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final File file; 
    private final TypeReference<List<T>>TypeReference;

    public FileManager(String filepath, TypeReference<List<T>>TypeReference){
        this.file = new File(filepath);
        this.TypeReference = TypeReference;

    }
    public List<T> read(){
        try{
            if (!file.exists()){
                return List.of();
            }
                return objectMapper.readValue(file, TypeReference);
        } catch (IOException e) {
            throw new RuntimeException("error al intentat leer el archivo JSON: "+file.getName(), e);
        }
    } 

    public void write(List<T>data){
        try {
            objectMapper.writerWithDefaultPrettyPrinter().writeValue(file, data);
        } catch (Exception e) {
            throw new RuntimeException("error al intentat leer el archivo JSON: "+file.getName(), e);
        }


    }

}
