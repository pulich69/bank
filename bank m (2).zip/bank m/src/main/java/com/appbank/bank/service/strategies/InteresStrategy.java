package com.appbank.bank.service.strategies;

public class InteresStrategy {

}
