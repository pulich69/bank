package com.appbank.bank.service;

import java.util.ArrayList;
import java.util.List;

import com.appbank.mi_appbank.model.Account;
import com.appbank.mi_appbank.model.Customer;

public class BankServiceImpl implements BankService {

    private List<Customer> customers;
    private List<Account> accounts;
    private InterestStrategy interestStrategy;

    public BankServiceImpl(InterestStrategy interestStrategy) {
        this.customers = new ArrayList<>();
        this.accounts = new ArrayList<>();
        this.interestStrategy = interestStrategy;
    }

    // Implementación del método crear cliente
    @Override
    public Customer createCustomer(String id, String name, String email) {
        Customer customer = new Customer(id, name, email);
        customers.add(customer);
        return customer;
    }

    // Implementación del método obtener todos los clientes
    public List<Customer> getAllCustomers() {
        return customers;
    }

    // Implementación del método buscar cliente por el id
    @Override
    public Customer findCustomerById(String customerId) {
        return customers.stream()
                .filter(c -> c.getId().equals(customerId))
                .findFirst()
                .orElse(null);
    }
}

