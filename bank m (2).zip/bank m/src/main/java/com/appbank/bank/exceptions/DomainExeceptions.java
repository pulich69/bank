package com.appbank.bank.exceptions;

public class DomainExeceptions extends RuntimeException { 
    public DomainExeceptions (String message){
        super(message);
    }

    public DomainExeceptions(String message, Throwable cause){
        super(message, cause);

    }

    
}
