package com.appbank.bank.service;

public interface InterestStrategy {
    double calculateInterest(double balance);

}
